package com.example.cookedchicken;

import net.fabricmc.api.ClientModInitializer;

public class CookedChickenClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {}
}