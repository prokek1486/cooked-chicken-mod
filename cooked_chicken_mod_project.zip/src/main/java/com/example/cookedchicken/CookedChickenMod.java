package com.example.cookedchicken;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.passive.ChickenEntity;

public class CookedChickenMod implements ModInitializer {
    public static final String MOD_ID = "cookedchicken";
    
    public static final TrackedData<Boolean> IS_COOKED_MODEL = DataTracker.registerData(ChickenEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    @Override
    public void onInitialize() {}
}