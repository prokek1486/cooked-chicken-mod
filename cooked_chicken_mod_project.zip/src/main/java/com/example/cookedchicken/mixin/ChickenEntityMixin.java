package com.example.cookedchicken.mixin;

import com.example.cookedchicken.CookedChickenMod;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChickenEntity.class)
public abstract class ChickenEntityMixin {

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    protected void injectDataTracker(DataTracker.Builder builder, CallbackInfo ci) {
        builder.add(CookedChickenMod.IS_COOKED_MODEL, false);
    }

    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        ChickenEntity chicken = (ChickenEntity) (Object) this;
        if (source.getAttacker() instanceof PlayerEntity player) {
            if (player.getMainHandStack().isEmpty()) {
                chicken.getDataTracker().set(CookedChickenMod.IS_COOKED_MODEL, true);
            }
        }
    }
}