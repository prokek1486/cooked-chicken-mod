package com.example.cookedchicken.mixin;

import com.example.cookedchicken.CookedChickenMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ChickenEntityRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChickenEntityRenderer.class)
public class ChickenEntityRendererMixin {

    @Inject(method = "render*", at = @At("HEAD"), cancellable = true)
    private void replaceChickenModel(ChickenEntity chicken, float f, float g, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int i, CallbackInfo ci) {
        if (chicken.getDataTracker().get(CookedChickenMod.IS_COOKED_MODEL)) {
            matrixStack.push();
            matrixStack.translate(0.0D, 0.5D, 0.0D);
            float yaw = (chicken.age + g) * 3.0F;
            matrixStack.multiply(new Quaternionf().rotationY(yaw * 0.017453292F));
            ItemStack cookedChickenStack = new ItemStack(Items.COOKED_CHICKEN);
            MinecraftClient.getInstance().getItemRenderer().renderItem(
                    cookedChickenStack,
                    ModelTransformationMode.GROUND,
                    i,
                    net.minecraft.client.render.OverlayTexture.DEFAULT_UV,
                    matrixStack,
                    vertexConsumerProvider,
                    chicken.getWorld(),
                    chicken.getId()
            );
            matrixStack.pop();
            ci.cancel();
        }
    }
}